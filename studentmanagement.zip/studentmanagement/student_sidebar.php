<header class="header">
    <a href="">Student Dashboard</a>
    <div class="logout">
        <a href="logout.php" class="btn btn-primary">Logout</a>
</div>
</header>
<aside>
    <ul>
        <li>
            <a href="student_profile.php">My Profile</a>
        </li>
        <li>
            <a href="">My Courses</a>
        </li>
        <li>
            <a href="">My Result</a>
        </li>
        
    </ul>
</aside>